# ======= Ticket 10161: Mobile Vulnerability, AES Encryption and decryption of request and response ====================
AES_KEY = '@!#$HDFCL@!#$@!#$HDFCL@!#$@!#$HD'
AES_IV = 'GE$5SGr@3VsAYUTa'