APP_OS = {
    'ANDROID': 'android',
    'IOS': 'ios'
}