ERROR_MESSAGE_KEYWORDS = ['timeout', "HTTPConnectionPool", "status code: 503"]
GENERIC_ERROR_MESSAGE = 'Something went wrong.'
GENERIC_ERROR_UPDATE_MESSAGE = 'Some error occurred. Please ensure you have the latest version of the app downloaded.'

ERROR_MAIL_MESSAGE = "Error message : {{error_message}} + <br/> URL : {{url}}"
ERROR_MAIL_SUBJECT = "HDFC Backend Error: Please check on ip - {{sys_ip}}"