APP_OS = {
    'ANDROID': 'android',
    'IOS': 'ios'
}

ERROR_MESSAGE_KEYWORDS = ['timeout', "HTTPConnectionPool", "status code: 503"]
GENERIC_ERROR_MESSAGE = 'Something went wrong.'
GENERIC_ERROR_UPDATE_MESSAGE = 'Some error occurred. Please ensure you have the latest version of the app downloaded.'
